<?php

namespace App\Http\Controllers;

use App\Models\Lab1Task;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Lab1TaskController extends Controller
{
    public function index()
    {
        $tasks = Auth::user()->tasks;
        return view('lab1_tasks.index', compact('tasks'));
    }

    public function create()
    {
        return view('lab1_tasks.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        Auth::user()->tasks()->create([
            'title' => $request->title,
            'description' => $request->description,
        ]);

        return redirect()->route('lab1_tasks.index');
    }

    public function edit(Lab1Task $task)
    {
        $this->authorize('update', $task);
        return view('lab1_tasks.edit', compact('task'));
    }

    public function update(Request $request, Lab1Task $task)
    {
        $this->authorize('update', $task);

        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        $task->update($request->only('title', 'description', 'completed'));

        return redirect()->route('lab1_tasks.index');
    }

    public function destroy(Lab1Task $task)
    {
        $this->authorize('delete', $task);
        $task->delete();

        return redirect()->route('lab1_tasks.index');
    }
}
?>
