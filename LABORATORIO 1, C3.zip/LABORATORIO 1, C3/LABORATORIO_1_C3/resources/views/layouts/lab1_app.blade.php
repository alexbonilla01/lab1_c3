<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="{{ asset('css/lab1_app.css') }}">
    <title>TaskMaster</title>
</head>
<body>
    <div class="container">
        @if(Auth::check())
            <nav>
                <ul>
                    <li><a href="{{ route('lab1_tasks.index') }}">Tareas</a></li>
                    <li>
                        <form action="{{ route('logout') }}" method="POST">
                            @csrf
                            <button type="submit">Cerrar sesión</button>
                        </form>
                    </li>
                </ul>
            </nav>
        @endif
        @yield('content')
    </div>
    <script src="{{ asset('js/lab1_app.js') }}"></script>
</body>
</html>
