@extends('layouts.lab1_app')

@section('content')
    <h1>Mis Tareas</h1>
    <a href="{{ route('lab1_tasks.create') }}">Crear Nueva Tarea</a>
    <ul>
        @foreach ($tasks as $task)
            <li>
                <a href="{{ route('lab1_tasks.edit', $task->id) }}">{{ $task->title }}</a>
                <form action="{{ route('lab1_tasks.destroy', $task->id) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Eliminar</button>
                </form>
            </li>
        @endforeach
    </ul>
@endsection
