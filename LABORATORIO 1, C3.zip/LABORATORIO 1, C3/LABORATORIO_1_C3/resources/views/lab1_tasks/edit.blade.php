@extends('layouts.lab1_app')

@section('content')
    <h1>Editar Tarea</h1>
    <form action="{{ route('lab1_tasks.update', $task->id) }}" method="POST">
        @csrf
        @method('PUT')
        <label for="title">Título</label>
        <input type="text" name="title" id="title" value="{{ $task->title }}">
        <label for="description">Descripción</label>
        <textarea name="description" id="description">{{ $task->description }}</textarea>
        <label for="completed">Completada</label>
        <input type="checkbox" name="completed" id="completed" {{ $task->completed ? 'checked' : '' }}>
        <button type="submit">Actualizar</button>
    </form>
@endsection
