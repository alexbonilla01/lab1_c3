<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Lab1UserController;
use App\Http\Controllers\Lab1TaskController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/register', function () {
    return view('auth.register');
})->name('register');

Route::post('/register', [Lab1UserController::class, 'register']);

Route::get('/login', function () {
    return view('auth.login');
})->name('login');

Route::post('/login', [Lab1UserController::class, 'login']);

Route::post('/logout', [Lab1UserController::class, 'logout'])->name('logout');

Route::middleware('auth')->group(function () {
    Route::resource('lab1_tasks', Lab1TaskController::class);
});
?>
